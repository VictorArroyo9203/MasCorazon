﻿/// <reference path="../corazonfuerte/index.html" />
/// <reference path="../corazonfuerte/index.html" />
$(document).ready(function () {

    ////////////////////////////// Manejo de links
  
    $("#AcercaDe").click(function () {

        url = "AcercaDe.html";
        $(location).attr('href', url);
    });

    $("#AcercaDe2").click(function () {

        url = "AcercaDe.html";
        $(location).attr('href', url);
    });

    $("#Mensaje2").click(function () {

        url = "Login.html";
        $(location).attr('href', url);
    });



    $("#Mensaje").click(function () {

        url = "estadisticas.html";
        $(location).attr('href', url);
    });


    $("#AcercaDe2").click(function () {

        url = "AcercaDe.html";
        $(location).attr('href', url);
    });

    $("#Atras").click(function () {

        url = "#panel-fixed-page1";
        $(location).attr('href', url);
    });

    $("#estadisticas").click(function () {

        url = "Mensaje.html";
        $(location).attr('href', url);
    });
    
    $("#tips").click(function () {

        url = "CuidateMenu.html";
        $(location).attr('href', url);
    });

    $("#prevencion").click(function () {

        url = "AprendeMenu.html";
        $(location).attr('href', url);
    });

    $("#registro").click(function () {

        url = "Registro.html";
        $(location).attr('href', url);
    });

    $("#inicio").click(function () {

        url = "Login.html";
        $(location).attr('href', url);
    });


    $("#prevencion2").click(function () {

        url = "AprendeMenu.html";
        $(location).attr('href', url);
    });

    $("#estadisticas2").click(function () {

        url = "Mensaje.html";
        $(location).attr('href', url);
    });

    $("#tips2").click(function () {

        url = "CuidateMenu.html";
        $(location).attr('href', url);
    });

    $("#menu").click(function () {

        url = "Menu.html";
        $(location).attr('href', url);
    });

    $("#juego").click(function () {

        url = "juego/index.html";
        $(location).attr('href', url);
    });

    $("#juego2").click(function () {

        url = "juego/index.html";
        $(location).attr('href', url);
    });

    $("#menu6").click(function () {

        url = "Menu.html";
        $(location).attr('href', url);
    });

    
    $("#RegistroT").click(function () {

        alert("Registro Exitoso");

        $("#TextBox1").val('');
        $("#TextBox2").val('');
        $("#TextBox3").val('');
        $("#TextBox4").val('');
        $("#TextBox5").val('');
        
        url = "Resultado.html";
        $(location).attr('href', url);
    });

    $("#mapa23").click(function () {

        url = "Mapa.html";
        $(location).attr('href', url);
    });

    $("#social").click(function () {

        url = "Twitter.html";
        $(location).attr('href', url);
    });

    $("#test2").click(function () {

        url = "Test.html";
        $(location).attr('href', url);
    });

    $("#test").click(function () {

        url = "Test.html";
        $(location).attr('href', url);
    });

    $("#fb").click(function () {

        url = "Facebook.html";
        $(location).attr('href', url);
    });

    $("#tw").click(function () {

        url = "Twitter.html";
        $(location).attr('href', url);
    });

    $("#tw3").click(function () {

        url = "Twitter.html";
        $(location).attr('href', url);
    });

    $("#tw2").click(function () {

        url = "Twitter.html";
        $(location).attr('href', url);
    });

    $("#registroM").click(function () {

        url = "Registro.html";
        $(location).attr('href', url);
    });

    $("#Aprende1").click(function () {

        url = "Prevencion.html";
        $(location).attr('href', url);
    });

    $("#google").click(function () {

        url = "google.html";
        $(location).attr('href', url);
    });

    $("#CuidateActividadFisica").click(function () {

        url = "CuidateActividadFisica.html";
        $(location).attr('href', url);
    });
  
    $("#AprendeNutricion").click(function () {

        url = "AprendeNutricion.html";
        $(location).attr('href', url);
    });

    $("#menu2").click(function () {

        url = "Menu.html";
        $(location).attr('href', url);
    });


    $("#CuidateNutricion").click(function () {

        url = "CuidateNutricion.html";
        $(location).attr('href', url);
    });

    $("#AprendeAutocuidado2").click(function () {

        url = "AprendeAutocuidado.html";
        $(location).attr('href', url);
    });

    $("#pupop1").click(function () {

        url = "#popupBasic";
        $(location).attr('href', url);
    });


    
});